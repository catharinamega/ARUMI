//
//  Quiz.swift
//  ARUMI
//
//  Created by Catharina Adinda Mega Cahyani on 16/01/23.
//

import Foundation
import SwiftUI
import UniformTypeIdentifiers


struct DragModel:  Identifiable, Codable, Transferable  {
    var id : String = UUID().uuidString
    var question : String

    var antacedent: [String]
    var choices: [String]
    var consequent: [String]
    
    
    static var transferRepresentation: some TransferRepresentation {
        CodableRepresentation(for: DragModel.self, contentType: .image)
    }
    
}

extension UTType {
    static var image = UTType(exportedAs: "REPLACE_THIS_WITH_YOUR_BUNDLE_ID.image")
}



var myQuiz2: [DragModel]  =
[
    DragModel(question: "Based on the past transaction above, minimum support 50% and minimum confidence 75%, if Mr. Arjuna buys fish then what item most likely to be bought also ?", antacedent: ["fish"], choices: ["ice","bagel","none"], consequent: ["ice"]),
    
    DragModel(question: "Based on the past transaction above, minimum support 50% and minimum confidence 75%, if Mr. Sadewa buys ice then what item most likely to be bought also ?", antacedent: ["ice"], choices: ["fish","honey","none"], consequent: ["none"]),
    
    DragModel(question: "Based on the past transaction above, minimum support 50% and minimum confidence 75%, if Mr. Pandu buys ice and honey then what item most likely to be bought also ?", antacedent: ["ice","honey"], choices: ["juice","fish","none"], consequent: ["fish"]),

    DragModel(question: "Based on the past transaction above, minimum support 50% and minimum confidence 75%, if Mr. Bagong buys ice then what item most likely to be bought also ?", antacedent: ["ice"], choices: ["fish","cheese", "none"], consequent: ["none"]),

    DragModel(question: "Based on the past transaction above, minimum support 50% and minimum confidence 75%, if Mr. Gareng buys honey then what two items most likely to be bought also ? DRAG 2 ITEMS, PLEASE", antacedent: ["honey"], choices: ["fish","ice","grapes"], consequent: ["fish", "ice"]),
    
]

class Trolley: ObservableObject, Identifiable {
    @Published var items = [DragModel]()
    @Published var dragged:String = ""
    @Published var userChoices:[String] = []
    init(dragged: String, userChoices: [String]) {
        self.userChoices = userChoices
        self.dragged = dragged
        items.append(contentsOf: myQuiz2)
        
    }
    
    func appendChoices(){
        
        userChoices.append(dragged)
        
    }
    // Add a method to reset the object's state
    func reset() {
        dragged = ""
        userChoices = []
    }
    
}
