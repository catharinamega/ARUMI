//
//  Transaction.swift
//  ARUMI
//
//  Created by Catharina Adinda Mega Cahyani on 16/01/23.
//

import Foundation

//build a object that store many transactions data
struct TransactionModel: Hashable, Identifiable{
    var id : String 
    var img : [String]
    var items: [String]
    
}

var transaction1 : [TransactionModel] = [
 
    TransactionModel(id: "T100", img: ["🍎","🥯","🧀","🍩"], items: ["apple","bagel","cheese","donut"]),
    
    TransactionModel(id: "T200", img: ["🥚","🐟","🍇","🍯","🧊"], items: ["egg","fish","grapes","honey","ice"]),
    
    TransactionModel(id: "T300", img: ["🐟","🍯","🧊","🧃"], items: ["fish","honey","ice","juice"]),
     
    TransactionModel(id: "T400", img: ["🥯","🧀","🧊"], items: ["bagel","cheese","ice"])

]
