//
//  ConclusionView.swift
//  ARUMI
//
//  Created by Catharina Adinda Mega Cahyani on 20/03/23.
//

import SwiftUI

struct ConclusionView: View {
    @Environment(\.colorScheme) var colorScheme
    @State var orientation: UIDeviceOrientation = UIDevice.current.orientation
    @State public var device = UIDevice.current.userInterfaceIdiom
    @Binding var largeItemset2: [Set<String>:Int]
    @Binding var keysLargeItemset2: Array<Array<String>>
    @Binding var largeItemset3: [Set<String>:Int]
    @Binding var keysLargeItemset3: Array<String>
    
    @State var dictConfidence2 = [Array<String>:Double]()
    @State var dictConfidence3 = [Array<String>:Double]()
    @State var dictConfidenceThree2nd = [Array<String>:Double]()
    
    @State var done:Bool = false
    //    var dictLargeItemset2: [Array<Array<String>> : Bool] = Dictionary()
    var dictLargeItemset2: [Array<Array<String>>: Bool] = [:]
    
    
    var combinations: [[String]] = [] // Generate combinations
    
    
    var body: some View {
        var _: [String] = []
        VStack{
            //            VStack{
            HStack{
                Text("Confidence(A -> B) = ")
                    .font(.system(size: device == .pad ? 20 : 10, weight: .medium, design: .default))
                    .aspectRatio(contentMode: .fit)
                VStack{
                    Text("number of transactions containing A and B")
                        .underline()
                        .aspectRatio(contentMode: .fit)
                        .font(.system(size: device == .pad ? 20 : 10, weight: .medium, design: .default))
                    Text("number of transactions containing A")
                        .baselineOffset(10)
                        .aspectRatio(contentMode: .fit)
                        .font(.system(size: device == .pad ? 20 : 10, weight: .medium, design: .default))
                        .lineLimit(nil)
                }
                
                
            }
            .background(.yellow)
            
            
            Text("Let's gather all the rule sets from Large Itemset 1, Large Itemset 2, and Large Itemset 3. Then, count confidence for all those rules. \nRules which have green checkmarks are the chosen rules fulfilled minimum confidence 75% & minimum support 50%. These rules are called Association Rules. That's why this game called Association RUle MIning.")
                .font(.system(size: device == .pad ? 25 : 15, weight: .medium, design: .default))
                .frame(maxWidth: .infinity, alignment: .center)
            
            //            LARGE ITEMSET 1
            HStack{
                Spacer()
                VStack{
                    ForEach(keysLargeItemset2, id: \.self) { set in
                        ForEach(set.sorted(), id: \.self) { item in
                            HStack{
                                Image(item)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 50, height: 50)
                                
                                Text("->")
                                    .font(.system(size: device == .pad ? 45: 30, weight: .light, design: .default))
                                Image(set.filter{ $0 != item }.first!)
                                
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 50, height: 50)
                                
                                    .onAppear{
                                        print("set keysLargeItemset2: ", set.sorted())
                                        dictConfidence2[ [item, set.filter{ $0 != item }.first!] ] = countConfidence(antacedent: item, consequent: set.filter{ $0 != item }.first!)
                                        
                                        print("dictConfidence2: ", dictConfidence2)
                                        
                                    }
                                
                                Text(" = \(String(format: "%.2f", dictConfidence2[ [item, set.filter{ $0 != item }.first!] ] ?? 0.0))" )
                                    .font(.system(size: device == .pad ? 30: 15, weight: .medium, design: .default))
                                
                                if dictConfidence2[ [item, set.filter{ $0 != item }.first!] ] ?? 0.0 < 75.00 {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundColor(.red)
                                        .frame(width: device == .pad ? 30 : 15)
                                    
                                    
                                }
                                else{
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.green)
                                    //                                        .frame(width: device == .pad ? 50 : 15)
                                    
                                }
                            }
                            .padding(0)
                            
                            
                        }
                        
                        
                    }
                }
                Spacer()
                VStack{
                    ForEach(keysLargeItemset3.indices, id: \.self) { i in
                        ForEach(keysLargeItemset3.indices, id: \.self) { j in
                            
                            if i < j {
                                let item1 = keysLargeItemset3[i]
                                let item2 = keysLargeItemset3[j]
                                let remaining = keysLargeItemset3.filter { $0 != item1 && $0 != item2 }
                                HStack{
                                    Image(item1)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 50, height: 50)
                                    
                                    Text("AND")
                                        .font(.system(size: device == .pad ? 30 : 15, weight: .light, design: .default))
                                    Image(item2)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 50, height: 50)
                                    
                                    Text("->")
                                        .font(.system(size: device == .pad ? 30 : 15, weight: .light, design: .default))
                                    
                                    Image(remaining.first!)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 50, height: 50)
                                    
                                    
                                        .onAppear{
                                            print("tes")
                                            dictConfidence2[[item1, item2, remaining.first!]] = countConfidenceThreeFirst(antacedent: [item1, item2], consequent: remaining.first ?? "")
                                            
                                            print("dictConfidenceThree: ", dictConfidence2)
                                            
                                        }
                                    
                                    
                                    Text(" = \(String(format: "%.2f", dictConfidence2[[item1,item2,remaining.first!]] ?? 0.0)) ")
                                        .font(.system(size: device == .pad ? 30: 15, weight: .medium, design: .default))
                                    if dictConfidence2[[item1,item2,remaining.first!]] ?? 0.0 < 75.00 {
                                        Image(systemName: "xmark.circle.fill")
                                            .foregroundColor(.red)
                                            .frame(width: device == .pad ? 30 : 15)
                                        
                                    }
                                    else{
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(.green)
                                            .frame(width: device == .pad ? 30 : 15)
                                        
                                        
                                    }
                                }
                                
                                
                                
                                
                            }
                            
                            
                            
                        }
                    }
                    
                    
                    
                    ForEach(keysLargeItemset3.indices, id: \.self) { i in
                        HStack{
                            let item1 = keysLargeItemset3[i]
                            let listItem:[String] = keysLargeItemset3.filter{ $0 != keysLargeItemset3[i]}
                            let item2 = listItem[0]
                            let remaining = keysLargeItemset3.filter { $0 != item1 && $0 != item2 }
                            
                            Image(item1)
                                .resizable()
                                .scaledToFit()
                            //                                .frame(width: device == .pad ? 30 : 15)
                            Text("->")
                                .font(.system(size: device == .pad ? 30 : 15, weight: .light, design: .default))
                            Image(item2)
                                .resizable()
                                .scaledToFit()
                            //                                .frame(width: device == .pad ? 30 : 15)
                            Text("AND")
                                .font(.system(size: device == .pad ? 30 : 15, weight: .light, design: .default))
                            
                            Image(remaining.first!)
                                .resizable()
                                .scaledToFit()
                            //                                .frame(width: device == .pad ? 30 : 15)
                            
                                .onAppear{
                                    
                                    dictConfidence2[[item1, item2, remaining.first!]] = countConfidenceThreeSecond(antacedent: item1, consequent:[item2, remaining.first ?? ""] )
                                    
                                    print("dictConfidenceThreeSecond: ", countConfidenceThreeSecond)
                                    
                                }
                            
                            Text(" = \(String(format: "%.2f", dictConfidence2[[item1,item2,remaining.first!]] ?? 0.0))" )
                                .font(.system(size: device == .pad ? 30: 15, weight: .medium, design: .default))
                            
                            if dictConfidence2[[item1,item2,remaining.first!]] ?? 0.0 < 75.00 {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundColor(.red)
                                    .frame(width: device == .pad ? 30 : 15)
                                
                            }
                            else{
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                    .frame(width: device == .pad ? 30 : 15)
                                
                            }
                        }
                        
                    }
                }
                Spacer()
            }
            
            
            //            }
            
        }
        .safeAreaInset(edge: .bottom) {
            Color.clear.frame(height: 10)
        }
        //        .padding(.top, 50)
        
    }
    
    func countConfidence(antacedent:String, consequent:String) -> Double {
        
        var nominator = 0
        var denominator = 0
        
        var dict = [Set<String>:Int]()
        for trans in transaction1{
            if trans.items.contains(antacedent){
                denominator += 1
            }
            
            if trans.items.contains(antacedent) && trans.items.contains(consequent){
                nominator += 1
            }
            print("nominator: ", nominator)
            print("denominator: ", denominator)
            
        }
        dict[Set(arrayLiteral: antacedent, consequent)] = nominator/denominator
        print("dict confidence: ", dict)
        return (Double(nominator) / Double(denominator) * 100)
    }
    
    func countConfidenceThreeFirst(antacedent:[String], consequent:String) -> Double {
        
        var nominator = 0
        var denominator = 0
        
        
        for trans in transaction1{
            if trans.items.contains(antacedent[0]) && trans.items.contains(antacedent[1]) {
                denominator += 1
            }
            
            if trans.items.contains(antacedent[0]) && trans.items.contains(antacedent[1]) && trans.items.contains(consequent){
                nominator += 1
            }
            
            
            print("nominator: ", nominator)
            print("denominator: ", denominator)
            
        }
        print("confidence three: ", Double(nominator) / Double(denominator) * 100)
        return (Double(nominator) / Double(denominator) * 100)
    }
    
    func countConfidenceThreeSecond(antacedent:String, consequent:[String]) -> Double {
        
        var nominator = 0
        var denominator = 0
        
        
        for trans in transaction1{
            if trans.items.contains(consequent[0]) && trans.items.contains(consequent[1]) &&
                trans.items.contains(antacedent){
                nominator += 1
            }
            
            if trans.items.contains(antacedent){
                denominator += 1
            }
            
            
            print("nominator: ", nominator)
            print("denominator: ", denominator)
            
        }
        print("confidence three 2nd: ", Double(nominator) / Double(denominator) * 100)
        return (Double(nominator) / Double(denominator) * 100)
    }
}

//struct ConclusionView_Previews: PreviewProvider {
//    static var previews: some View {
//        ConclusionView()
//    }
//}
