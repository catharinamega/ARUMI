//
//  ChoicesView.swift
//  ARUMI
//
//  Created by Catharina Adinda Mega Cahyani on 18/01/23.
//

import SwiftUI


struct ChoicesView: View {
    
    @Binding var animated: [Bool]
    @Binding var trolleyPosition: CGPoint
    @State var moving = false
    let choicesItem: DragModel
    @Binding var index: Int
    @Binding var device:UIUserInterfaceIdiom
    
    var body: some View {
        GeometryReader{ reader in
            Group{
                VStack{
                    Image(choicesItem.choices[index])
                        .resizable()
                        .scaledToFit()
                        .frame(width: device == .pad ? 300 : 100, height:  device == .pad ? 200: 80)
                    
                    Text(choicesItem.choices[index])
                        .font(.system(size: device == .pad ? 45 : 15, weight: .light, design: .default))
                }
                
            }
            .animation(.linear, value: animated[index])
            //            IMAGE COUNT CONSEQUENT
            .offset(x: animated[index] ? (0 - reader.frame(in: .named("troli")).origin.x) + reader.size.width*2/3 - 150 : 0,
                    y: animated[index] ? 0 - reader.frame(in: .named("troli")).origin.y + trolleyPosition.y * 2.3 : 0)
            .onAppear{
                
            }
        }
        .draggable(choicesItem.choices[index])
    }
}



//struct ChoicesView_Previews: PreviewProvider {
//    static var previews: some View {
//        ChoicesView()
//    }
//}
