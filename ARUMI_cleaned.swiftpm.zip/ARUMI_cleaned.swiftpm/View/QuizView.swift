//
//  QuizView.swift
//  ARUMI
//
//  Created by Catharina Adinda Mega Cahyani on 16/01/23.
//

import SwiftUI

struct QuizView: View {
    @Environment(\.colorScheme) var colorScheme
    
    @State var i : Int = Int.random(in: 0..<5)
    
    
    @State private var showActionSheet = false
    
    @State private var imagePosition = [CGPoint.zero, CGPoint.zero, CGPoint.zero]
    @State var trolleyPosition = CGPoint.zero
    
    
    @State var selected: String = ""
    
    
    @State var orientation: UIDeviceOrientation = UIDevice.current.orientation
    @State public var device = UIDevice.current.userInterfaceIdiom
    @State private var image = Image("trolley")
    @State var isDropTargeted = false
    
    @State var result = false
    
    @StateObject var trolley:Trolley = Trolley(dragged: "", userChoices: [])
    
    
    @State private var draggedItem: String?
    
    @State var animated = [Bool]()
    
    @State var disabled:Bool = true
    @State var done:Bool = false
    @State var itemIndex: Int = 0
    
    
    init() {
        _animated = State(initialValue: fillAnimated())
        print("test init ", self.animated )
    }
    
    func fillAnimated() -> [Bool] {
        var temp_anim = [Bool]()
        
        self.i = Int.random(in: 0..<5)
        
        for _ in myQuiz2[self.i].choices.indices{
            temp_anim.append(false)
        }
        print("temp_animated ", temp_anim)
        return temp_anim
    }
    
    
    @State var arrayIndex:[Int] = []
    
    var body: some View{
        
        GeometryReader{ geo in
            
            ZStack{
                HStack{
                    VStack(spacing: device == .pad ? 20 : 10){
                        //                        MARK: USE TABLE
                        
                        TableTransactionView()
                            .scrollDisabled(true)
                        
                        Text(myQuiz2[self.i].question)
                            .font(.system(size: device == .pad ? 30 : 20, weight: .medium, design: .rounded))
                            .frame(maxWidth: .infinity, alignment: .center)
                        Spacer()
                        
                        //                image
                        HStack(){
                            VStack{
                                ForEach(myQuiz2[i].antacedent,id:\.self){ image in
                                    Image(image)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: device == .pad ? 100 : 50)
                                    
                                }
                            }
                            
                            Image(systemName: "arrow.right")
                                .resizable()
                                .scaledToFit()
                                .frame(width: device == .pad ? 100 : 50)
                            
                            
                            Image(systemName: "questionmark")
                                .resizable()
                                .scaledToFit()
                                .foregroundColor(Color(.gray))
                                .frame(width: device == .pad ? 100 : 50)
                            
                            
                            
                            
                        }
                        Spacer()
                        
                        image
                            .resizable()
                            .scaledToFit()
                            .frame(width: device == .pad ? 150 : 50)
                        
                            .dropDestination(for: String.self) { items, location in
                                draggedItem = items.first
                                guard let draggedItem = draggedItem else {
                                    return false;
                                }
                                
                                trolley.dragged = draggedItem
                                if trolley.userChoices.count < myQuiz2[self.i].consequent.count{
                                    trolley.appendChoices()
                                    
                                }
                                
                                
                                return true
                            } isTargeted: { inDropArea in
                                
                            }
                        Spacer()
                        
                        HStack {
                            ForEach(trolley.userChoices, id: \.self){ item in
                                Text(item)
                                    .font(.system(size: device == .pad ? 45: 15, weight: .light, design: .default))
                                    .onAppear{
                                        if trolley.userChoices.count == myQuiz2[self.i].consequent.count{
                                            disabled = false
                                        }
                                    }
                            }
                        }
                        
                        if self.done == false{
                            Button {
                                
                                if Set(trolley.userChoices).isSubset(of: Set(myQuiz2[self.i].consequent)){
                                    self.result = true
                                }
                                else{
                                    self.result = false
                                }
                                
                                
                                print(myQuiz2[self.i].choices)
                                
                                
                                
                                self.trolleyPosition.x = geo.frame(in: .global).midX/2
                                print(geo.frame(in: .global).midX)
                                //                            TINGGAL CARI EXACT Y POSITION TROLI
                                self.trolleyPosition.y = geo.frame(in: .global).midY/2
                                
                                for i in myQuiz2[self.i].consequent{
                                    arrayIndex.append(myQuiz2[self.i].choices.firstIndex(of: i)! )
                                    
                                }
                                
                                for j in arrayIndex{
                                    animated[j] = true
                                    print(animated[j])
                                    
                                }
                                self.done = true
                                
                            } label: {
                                ZStack{
                                    Text("Check My Trolley")
                                        .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                                        .foregroundColor(colorScheme == .dark ? .white : .black)
                                        .padding()
                                        .frame(maxWidth: .infinity, alignment: .center)
                                        .background(
                                            RoundedRectangle(cornerRadius: 8)
                                        )
                                }
                                
                                
                                
                            }
                            
                            .disabled(disabled)
                        }
                        else{
                            
                            NavigationLink {
                                ResultView(result: $result)
                            } label: {
                                ZStack{
                                    Text("Show the Result")
                                        .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                                        .foregroundColor(colorScheme == .dark ? .white : .black)
                                        .padding()
                                        .frame(maxWidth: .infinity, alignment: .center)
                                        .background(
                                            RoundedRectangle(cornerRadius: 8)
                                        )
                                }
                            }
                            
                        }
                        
                    }
                    VStack(alignment: .center){
                        ZStack{
                            Text("Disclaimer: Press and hold the item a little bit longer and then drag to the trolley ")
                                .foregroundColor(.red)
                                .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                            
                            
                        }
                        .background(.yellow)
                        .border(.red)
                        
                        ForEach(Array(zip(myQuiz2[i].choices.indices,myQuiz2[i].choices)), id: \.0){ index, element in
                            
                            var index = index
                            ChoicesView(animated: $animated, trolleyPosition: $trolleyPosition, choicesItem: myQuiz2[i], index: Binding<Int>(
                                get: { index },
                                set: { newValue in index = newValue }
                            ), device: $device
                            )
                            
                        }
                        
                    }
                    
                    .onAppear{
                    }
                    .padding()
                }
                .coordinateSpace(name: "troli")
                
            }
            .onAppear{
                self.i = Int.random(in: 0..<5)
                self.animated =  fillAnimated()
                
            }
            
        }
        .onAppear{
            self.i = Int.random(in: 0..<5)
            self.animated =  fillAnimated()
            
            //                reset all
            arrayIndex = []
            trolley.reset()
            result = false
            done = false
            disabled = true
        }
        
    }
    
}


