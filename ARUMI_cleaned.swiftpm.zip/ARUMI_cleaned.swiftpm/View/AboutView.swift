//
//  SwiftUIView.swift
//  
//
//  Created by Catharina Adinda Mega Cahyani on 18/04/23.
//

import SwiftUI

struct AboutView: View {
    var body: some View {
        VStack(spacing: 300) {
            
            Image("storytelling_2")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 200)
                .padding(.top,300)
            
            VStack{
                Text("Story behind ARUMI")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                
                Text("Do you ever wonder how supermarket arranges their items on display?\nDid you know that when beers are moved next to diapers section, the sales jumped?\nThe trick lies in applying the Association Rule Mining.\nAssociation rule mining (ARM) is the process of identifying connections between multiple variables from a large dataset. In simpler terms, ARM examines a database of records that contain two or more variables with their corresponding values, and it identifies the combinations of variables and values that occur most frequently.\nAs a lecturer's assistant in Data Mining subject deal with this method regularly. For my juniors, explaining the method is very difficult, let alone doing the tracing. I found that my juniors had so much difficulty catching up with the tracing. Especially, when our Professor taught the algorithm on the medium whiteboard like the picture above.\nThis is why I created ARUMI, a simple simulation game to guide students to learn and trace Association Rule Mining. I hope that this can help my juniors perform tracing and explain Association Rule Mining better.")
                    .font(.system(size: 25, weight: .medium))
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity)
            }
            //            .padding(.bottom, 50)
            //            .padding(.horizontal)
            
        }
        
    }
}



struct AboutView_Previews: PreviewProvider {
    static var previews: some View {
        AboutView()
    }
}
