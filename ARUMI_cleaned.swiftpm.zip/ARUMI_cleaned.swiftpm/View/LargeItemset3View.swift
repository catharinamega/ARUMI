//
//  LargeItemset3View.swift
//  ARUMI
//
//  Created by Catharina Adinda Mega Cahyani on 12/03/23.
//

import SwiftUI


struct LargeItemset3View: View {
    @Environment(\.colorScheme) var colorScheme
    @State var orientation: UIDeviceOrientation = UIDevice.current.orientation
    @State public var device = UIDevice.current.userInterfaceIdiom
    @Binding var dictCandidateThree: [Set<String>:Int]
    @State var largeItemset3 = [Set<String>:Int]()
    @State var sortedDict = Array<(key: Set<String>, value: Int)>()
    @State var keysArray = Array<Array<String>>()
    @State var newArray = [[String]]()
    @State var candidateThree = Array<Array<String>>()
    @State var done:Bool = false
    @State var candidateThreeUpdated = Array<String>()
    @State private var countAnd: Int = 0
    var body: some View {
        
        
        GeometryReader{ geo in
            VStack{
                //                        MARK: USE TABLE
                TableTransactionView()
                    .frame(width: device == .pad ? 700: 400, height: device == .pad ? 400: 200)
                
                Text("Let's create triple items combinations from Large Itemset 2\nThey are called Candidate of Large Itemset 3\nNow, let's count how many occurrences of each triple of the rule sets in the transaction. If there are any triple do not fulfill the minimum support 50% or occur less than two occurrences, they should be eliminated.")
                    .font(.system(size: device == .pad ? 30: 15, weight: .medium, design: .default))
                Spacer()
                
                VStack{
                    ForEach(candidateThree, id:\.self) {  candidate in
                        HStack{
                            ForEach(candidate.indices, id:\.self) { index in
                                if index != 0 {
                                    Text("AND") // Add the Text view after the first image
                                        .font(.system(size: device == .pad ? 45: 15, weight: .light, design: .default))
                                }
                                Image(candidate[index])
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: device == .pad ? 90: 30)
                            }
                            if let value = largeItemset3[Set(candidate.lazy)] {
                                Text(" = \(value)") // returns "1"
                                    .font(.system(size: device == .pad ? 45: 15, weight: .light, design: .default))
                            } else {
                                Text("")
                                
                            }
                            
                        }
                        Spacer()
                        
                        
                    }
                }
                
                if done{
                    
                    NavigationLink(destination: ConclusionView(largeItemset2: $dictCandidateThree, keysLargeItemset2: $keysArray, largeItemset3: $largeItemset3, keysLargeItemset3: $candidateThreeUpdated)) {
                        VStack{
                            ItemsetThree(device: $device, candidateThreeUpdated: $candidateThreeUpdated)
                            ZStack{
                                Text("See the Final Rule Sets")
                                    .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                                    .foregroundColor(colorScheme == .dark ? .white : .black)
                                    .padding()
                                    .fixedSize(horizontal: true, vertical: false)
                                    .frame(alignment: .center)
                                    .background(
                                        RoundedRectangle(cornerRadius: 8)
                                    )
                                
                            }
                        }
                        
                    }
                    
                    
                }
                else{
                    Button {
                        
                        largeItemset3 = largeItemset3.filter { $0.value >= 2 }
                        candidateThree = largeItemset3.map { Array($0.key) }
                        print("largeItemsetThree after eliminated: ", largeItemset3)
                        print("candidateThree after eliminated: ", candidateThree)
                        guard !candidateThree.isEmpty else {
                            print("candidateThree is empty")
                            return
                        }
                        candidateThreeUpdated = candidateThree[0].map({ String($0) })
                        candidateThreeUpdated = candidateThreeUpdated.sorted()
                        print("candidateThreeUpdated: ", candidateThreeUpdated)
                        done = true
                        
                        
                        
                    }
                label: {
                    ZStack{
                        Text("Eliminate Rule Set")
                            .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                            .foregroundColor(colorScheme == .dark ? .white : .black)
                            .padding()
                            .fixedSize(horizontal: true, vertical: false)
                            .frame(alignment: .center)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                            )
                    }
                    
                    
                    
                }
                }
            }
            .frame( minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
            .onAppear{
                largeItemset3 = [:]
            }
        }
        .onAppear{
            sortedDict = dictCandidateThree.sorted { (lhs, rhs) -> Bool in
                return lhs.key.sorted().lexicographicallyPrecedes(rhs.key.sorted())
            }
            sortedDict.sort { $0.key.sorted().lexicographicallyPrecedes($1.key.sorted()) }
            keysArray = sortedDict.map { Array($0.key) }
            
            
            keysArray = keysArray.sorted {
                let aSorted = $0.sorted()
                let bSorted = $1.sorted()
                for i in 0..<min(aSorted.count, bSorted.count) {
                    if aSorted[i] < bSorted[i] {
                        return true
                    } else if bSorted[i] < aSorted[i] {
                        return false
                    }
                }
                return aSorted.count < bSorted.count
            }
            
            
            print("Sorted dictCandidateThree: ", sortedDict)
            print("Type of sortedDict: ", type(of: sortedDict))
            print("keysArray: ",keysArray)
            
            var sortedKeysArray = keysArray.sorted { $0[0] < $1[0] }
            
            for i in 0..<sortedKeysArray.count{
                sortedKeysArray[i].sort(by:<)
                
            }
            
            
            for i in 0..<sortedKeysArray.count {
                print("Loop \(i+1): \(sortedKeysArray[i])")
                
                for j in stride(from: i+1, to: sortedKeysArray.count, by: 1) {
                    print("\tInner loop \(j-i): \(sortedKeysArray[j])")
                    if !sortedKeysArray[i].contains(sortedKeysArray[j].last!){
                        print("last: ", sortedKeysArray[j].last!)
                        var temp_can:[String] = sortedKeysArray[i]
                        temp_can.append(sortedKeysArray[j].last!)
                        print("temporary candidate: ", temp_can)
                        if !newArray.contains(temp_can){
                            newArray.append(contentsOf: [temp_can])
                        }
                        
                        temp_can = []
                    }
                    //                            sortedKeysArray[i].append(sortedKeysArray[j].last!)
                }
            }
            
            //                newArray = result
            print("newArray: ", newArray)
            candidateThree = Array(Set(newArray.map{ Set($0) })).map{ Array($0) }
            print("candidateThree: ", candidateThree, "\ntype: ", type(of: candidateThree))
            
            for candidate in candidateThree{
                print("candidate: ", candidate)
                for trans in transaction1{
                    if(trans.items.contains(candidate[0]) && trans.items.contains(candidate[1]) && trans.items.contains(candidate[2]) ){
                        print("candidate passed: ", candidate, "\ntransaction: ", trans)
                        
                        largeItemset3[Set(arrayLiteral: candidate[0],candidate[1],candidate[2])] = (largeItemset3[Set(arrayLiteral: candidate[0],candidate[1],candidate[2])] ?? 0) + 1
                        
                        
                    }
                    else{
                        largeItemset3[Set(arrayLiteral: candidate[0],candidate[1],candidate[2])] = (largeItemset3[Set(arrayLiteral: candidate[0],candidate[1],candidate[2])] ?? 0) + 0
                    }
                    
                }
                
            }
            
            
            print("Large Itemset 3: ",largeItemset3)
            done = false
            
        }
        
    }
}


struct ItemsetThree: View {
    @Binding var device:UIUserInterfaceIdiom
    @Binding var candidateThreeUpdated:Array<String>
    var body: some View{
        HStack{
            Text("Large Itemset 3 = { ")
                .font(.system(size: device == .pad ? 30 : 15, weight: .light, design: .default))
            
            ForEach(Array(arrayLiteral: candidateThreeUpdated),id:\.self) { key in
                
                ForEach(key,id:\.self) { item in
                    Image(item)
                        .resizable()
                        .scaledToFit()
                        .frame(width: device == .pad ? 45 : 15)
                    
                }
                
            }
            
            Text("}")
                .font(.system(size: device == .pad ? 30 : 15, weight: .light, design: .default))
            
            
        }
    }
}




