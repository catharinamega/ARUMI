//
//  LargeItemset2View.swift
//  ARUMI
//
//  Created by Catharina Adinda Mega Cahyani on 27/02/23.
//

import SwiftUI
import Foundation

struct LargeItemset2View: View {
    @Environment(\.colorScheme) var colorScheme
    @State var orientation: UIDeviceOrientation = UIDevice.current.orientation
    @State public var device = UIDevice.current.userInterfaceIdiom
    @Binding var LargeItemset1:Set<String>
    @State var candidateTwo = Set<Set<String>>()
    @State var dictCandidateTwo = [Set<String>:Int]()
    
    @State var tempCandidate:[String] = []
    @State var itemSet2:[String] = []
    @State var temp_item:[String] = []
    var body: some View {
        
        VStack{
            
            //                        MARK: USE TABLE
            TableTransactionView()
                .frame(width: device == .pad ? 700: 400, height: device == .pad ? 400: 200)
            
            Text("Let's create pairs of items from Large Itemset 2\nThey are called Candidate of Large Itemset 2\nNow, let's count how many occurrences of each pair of these rule sets in the transaction. If there are any pairs do not fulfill the minimum support 50% or occur less than 2 occurrences, they should be eliminated.")
                .font(.system(size: device == .pad ? 30: 15, weight: .medium, design: .default))
            
            
            ImageCandidate(dictCandidateTwo: $dictCandidateTwo, tempCandidate: $tempCandidate)
            
        }
        .onAppear{
            for item in LargeItemset1{
                for j in LargeItemset1{
                    if j != item{
                        candidateTwo.insert([item,j])
                    }
                }
            }
            print(candidateTwo)
            
            for candidate in candidateTwo{
                tempCandidate = Array(candidate)
                for trans in transaction1{
                    if(trans.items.contains(tempCandidate[0]) && trans.items.contains(tempCandidate[1]) ){
                        print("tempCandidate: ", tempCandidate)
                        dictCandidateTwo[Set(arrayLiteral: tempCandidate[0],tempCandidate[1])] = (dictCandidateTwo[Set(arrayLiteral: tempCandidate[0],tempCandidate[1])] ?? 0) + 1
                        print("dictCandidateTwo: ",dictCandidateTwo)
                    }
                }
                
            }
            
            for (key, _) in dictCandidateTwo {
                for item in key{
                    temp_item.append(item)
                    
                }
                itemSet2.append(contentsOf: temp_item)
            }
            print("itemSet2: ", itemSet2)
        }
    }
    
}

struct ImageCandidate: View{
    @Environment(\.colorScheme) var colorScheme
    @State var orientation: UIDeviceOrientation = UIDevice.current.orientation
    @State public var device = UIDevice.current.userInterfaceIdiom
    @Binding var dictCandidateTwo:[Set<String>:Int]
    @Binding var tempCandidate:[String]
    @State var itemsOfCandidate = [String]()
    @State private var countAnd: Int = 0
    @State private var opacity: Int = 1
    @State var dictEliminate = [Int : Int]()
    @State var done:Bool = false
    @State var dictCandidateThree = Array<(key: Set<String>, value: Int)>()
    var body: some View{
        var candidateKey = dictCandidateTwo.keys.sorted { (set1, set2) -> Bool in
            let sorted1 = set1.sorted()
            let sorted2 = set2.sorted()
            return sorted1.lexicographicallyPrecedes(sorted2)
        }
        //        var hiddenAnd = 0
        //        var candidateList = [String]()
        var valueItem = ""
        
        GeometryReader{ geo in
            VStack(alignment: .center){
                ForEach(Array(candidateKey),id:\.self) { candidate in
                    HStack(){
                        ForEach(Array(candidate.enumerated()),id:\.element) { (index,item) in
                            HStack{
                                Image(String(item))
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: device == .pad ? 100: 50)
                                    .onAppear{
                                        countAnd += 1
                                        
                                    }
                                
                                if (index < 1) {
                                    Text("AND")
                                        .font(.system(size: device == .pad ? 45: 15, weight: .light, design: .default))
                                        .onAppear{
                                            countAnd = 0
                                            
                                        }
                                    
                                    
                                }
                                
                            }
                            
                            
                        }
                        Text("=")
                            .font(.system(size: device == .pad ? 45: 15, weight: .light, design: .default))
                        
                        Text(String(dictCandidateTwo[candidate] ?? 0))
                            .font(.system(size: device == .pad ? 45: 15, weight: .light, design: .default))
                            .onAppear{
                                print("last value item: ", valueItem)
                            }
                        
                    }
                    .onAppear{
                        
                        valueItem =  String(dictCandidateTwo[candidate] ?? 0)
                        print("value item: ", valueItem)
                        //                    MARK: INI BUAT DICTIONARY VALUENYA ISHIDDEN
                        for (index, _) in Array(dictCandidateTwo.enumerated()) {
                            print("index: ", index)
                            dictEliminate[index] = Array(dictCandidateTwo.values)[index] ?? 0
                            
                            
                        }
                        print("dictEliminate: ", dictEliminate)
                        
                    }
                    
                    
                }
                
                if done{
                    NavigationLink {
                        LargeItemset3View(dictCandidateThree: $dictCandidateTwo)
                    } label: {
                        VStack{
                            HStack{
                                Text("Large Itemset 2 = { ")
                                    .font(.system(size: device == .pad ? 30 : 15, weight: .light, design: .default))
                                ForEach(Array(candidateKey),id:\.self) { key in
                                    Text("{ ")
                                        .font(.system(size: device == .pad ? 45 : 15, weight: .light, design: .default))
                                    ForEach(Array(key),id:\.self) { item in
                                        Image(item)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: device == .pad ? 45 : 15)
                                        
                                    }
                                    Text(" }")
                                        .font(.system(size: device == .pad ? 45 : 15, weight: .light, design: .default))
                                    
                                }
                                Text(" }")
                                    .font(.system(size: device == .pad ? 45 : 15, weight: .light, design: .default))
                            }
                            .frame(maxWidth: .infinity)
                            
                            
                            ZStack{
                                Text("Generate Large Itemset 3")
                                    .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                                    .foregroundColor(colorScheme == .dark ? .white : .black)
                                    .padding()
                                    .fixedSize(horizontal: true, vertical: false)
                                    .frame(alignment: .center)
                                    .background(
                                        RoundedRectangle(cornerRadius: 8)
                                    )
                                
                            }
                            
                        }
                        
                        
                        
                    }
                }
                else{
                    Button{
                        for key in candidateKey{
                            if dictCandidateTwo[key] ?? 0 < 2{
                                print("Eliminated candidate: ", key)
                                dictCandidateTwo.removeValue(forKey: key)
                            }
                        }
                        candidateKey = dictCandidateTwo.keys.sorted { (set1, set2) -> Bool in
                            let sorted1 = set1.sorted()
                            let sorted2 = set2.sorted()
                            return sorted1.lexicographicallyPrecedes(sorted2)
                        }
                        candidateKey.sort { $0.sorted().joined() < $1.sorted().joined()
                            
                        }
                        
                        print("Final Candidate Key: ", candidateKey)
                        print("Type of Candidate Key: ", type(of: candidateKey))
                        print("Type of dictCandidateTwo: ", type(of: dictCandidateTwo))
                        let sortedDict = dictCandidateTwo.sorted { (entry1, entry2) -> Bool in
                            let sortedKey1 = entry1.key.sorted(by: <)
                            let sortedKey2 = entry2.key.sorted(by: <)
                            return sortedKey1.lexicographicallyPrecedes(sortedKey2)
                        }
                        
                        dictCandidateTwo = Dictionary(uniqueKeysWithValues: sortedDict)
                        
                        print("Sorted Dict: ", sortedDict, "\ntype Sorted Dict: ",type(of: sortedDict) )
                        
                        print("Final dictCandidateTwo: ", dictCandidateTwo)
                        dictCandidateThree = dictCandidateTwo.sorted { (lhs, rhs) -> Bool in
                            return lhs.key.sorted().lexicographicallyPrecedes(rhs.key.sorted())
                        }
                        done = true
                    }
                label: {
                    ZStack{
                        Text("Eliminate Rule Set")
                            .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                            .foregroundColor(colorScheme == .dark ? .white : .black)
                            .padding()
                            .fixedSize(horizontal: true, vertical: false)
                            .frame(alignment: .center)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                            )
                    }
                    
                    
                    
                }
                    
                }
                
                
                
            }
            .frame(width: geo.size.width, height: geo.size.height, alignment: .center)
            .onAppear{
                dictCandidateTwo = [:]
                done = false
                
            }
        }
        
    }
    
}
