//
//  SwiftUIView.swift
//  
//
//  Created by Catharina Adinda Mega Cahyani on 18/04/23.
//

import SwiftUI
import AVKit

struct HowToPlayView: View {
    var videoPlayer = AVPlayer(url: Bundle.main.url(forResource: "How_To_Play", withExtension: "mp4")!)
    
    
    var body: some View {
        
        //        VStack{
        //            VideoPlayer(player:videoPlayer)
        //                .aspectRatio(CGSize(width: 1376, height: 630), contentMode: .fill)
        //                .frame(maxWidth: .infinity, maxHeight: .infinity)
        //                .disabled(true)
        //
        //        }
        //        .navigationViewStyle(.stack)
        //        .onAppear{
        //            // Video
        //            videoPlayer.play()
        //            NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: nil, queue: .main) { _ in
        //                videoPlayer.seek(to: .zero)
        //                videoPlayer.play()
        //            }
        //
        //        }
        
        if let url = Bundle.main.url(forResource: "How_To_Play", withExtension: "mp4") {
            let player = AVPlayer(url: url)
            return AnyView(
                VideoPlayer(player: player)
                    .onAppear{
                        player.play()
                        NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: nil, queue: .main) { _ in
                            player.seek(to: .zero)
                            player.play()
                        }
                        
                        
                    }
                    .onDisappear{
                        player.pause()
                    }
            )
        } else {
            return AnyView(
                Text("Video not found")
            )
        }
    }
}

struct HowToPlayView_Previews: PreviewProvider {
    static var previews: some View {
        HowToPlayView()
    }
}
