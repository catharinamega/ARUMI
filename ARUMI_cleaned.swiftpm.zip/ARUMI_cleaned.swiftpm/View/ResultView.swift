//
//  ResultView.swift
//  ARUMI
//
//  Created by Catharina Adinda Mega Cahyani on 04/02/23.
//

import SwiftUI

struct ResultView: View {
    @Environment(\.colorScheme) var colorScheme
    @Binding var result:Bool
    @State var orientation: UIDeviceOrientation = UIDevice.current.orientation
    @State public var device = UIDevice.current.userInterfaceIdiom
    var body: some View {
        VStack(spacing: 20){
            HStack{
                if(self.result){
                    Text("Your answer is right 💅")
                        .bold()
                        .font(.system(size: device == .pad ? 90: 30, weight: .bold, design: .default))
                    
                    
                }
                else{
                    Text("Your answer is wrong 🗿")
                        .bold()
                        .font(.system(size: device == .pad ? 90: 30, weight: .bold, design: .default))
                    
                }
            }
            .background(self.result ? .green : .red)
            
            
            
            Text("You Finish!\n In case you don't know what happened, this mini quiz applies Association Rule Mining.\n")
            //                .frame( alignment: .center)
                .multilineTextAlignment(.center)
                .font(.system(size: device == .pad ? 90: 30, weight: .light, design: .default))
            
            NavigationLink(destination: LargeItemset1View()) {
                ZStack{
                    RoundedRectangle(cornerRadius: 10.0)
                        .fill(Color.cyan)
                        .frame(width: device == .pad ? 750 : 200,  height: device == .pad ? 100 : 50)
                    Text("Let's learn Association Rule Mining")
                        .font(.system(size: device == .pad ? 45 : 15, weight: .semibold, design: .rounded))
                        .foregroundColor(colorScheme == .dark ? .white : .black)
                }
                
                
            }
            
        }
        
    }
}

//struct ResultView_Previews: PreviewProvider {
//    static var previews: some View {
//        ResultView(result: Binding<false>)
//    }
//}
