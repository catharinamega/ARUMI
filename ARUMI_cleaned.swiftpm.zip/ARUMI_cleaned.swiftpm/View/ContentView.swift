import SwiftUI

struct ContentView: View {
    @State var orientation: UIDeviceOrientation = UIDevice.current.orientation
    @State public var device = UIDevice.current.userInterfaceIdiom
    
    
    var body: some View {
        NavigationView{
            
            VStack(spacing: device == .pad ? 60: 50){
                
                
                Text("ARUMI")
                    .font(.system(size: device == .pad ? 60: 40, weight: .bold, design: .rounded))
                
                Text("Association RUle MIning Simulation Game")
                
                    .font(.system(size: device == .pad ? 30: 20, weight: .medium, design: .rounded))
                
                NavigationLink(destination: QuizView()) {
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 10.0)
                            .fill(Color.blue)
                            .frame(width: 300, height: 50)
                        Text("Start the Game!")
                            .font(.system(size: device == .pad ? 30: 20, weight: .semibold, design: .rounded))
                            .foregroundColor(.white)
                        
                    }
                    
                }
                
                NavigationLink(destination: HowToPlayView()) {
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 10.0)
                            .fill(Color.yellow)
                            .frame(width: 300, height: 50)
                        Text("How to Play?")
                            .font(.system(size: device == .pad ? 30: 20, weight: .semibold, design: .rounded))
                            .foregroundColor(.white)
                        
                    }
                    
                }
                
                
                NavigationLink(destination: AboutView()) {
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 10.0)
                            .fill(Color.brown)
                            .frame(width: 300, height: 50)
                        Text("Story behind ARUMI")
                            .font(.system(size: device == .pad ? 30: 20, weight: .semibold, design: .rounded))
                            .foregroundColor(.white)
                        
                    }
                    
                }
                
                
                Text("Please build on XCode iPad 12.9 inch Simulator with iOS 16")
                    .font(.system(size: device == .pad ? 24: 12, weight: .light, design: .default))
                    .foregroundColor(Color.gray)
            }
            .navigationBarTitle("Association Rule Mining",displayMode: .inline)
            
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
