//
//  SwiftUIView.swift
//  
//
//  Created by Catharina Adinda Mega Cahyani on 11/04/23.
//

import SwiftUI

struct TableTransactionView: View {
    @Environment(\.colorScheme) var colorScheme
    @State var orientation: UIDeviceOrientation = UIDevice.current.orientation
    @State public var device = UIDevice.current.userInterfaceIdiom
    var body: some View {
        Table(transaction1) {
            TableColumn("Transaction") { trans in
                //                Text(trans.items.joined(separator: ", "))
                //                    .font(.system(size: device == .pad ? 45: 15, weight: .light, design: .default))
                HStack{
                    ForEach(trans.items, id:\.self) { item in
                        
                        Image(item)
                            .resizable()
                            .scaledToFit()
                            .frame(width: device == .pad ? 45 : 20)
                    }
                }
                
                
                
            }
            
        }
        
        .frame(maxHeight: 300)
        
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        TableTransactionView()
    }
}
