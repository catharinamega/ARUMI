//
//  LargeItemset1View.swift
//  ARUMI
//
//  Created by Catharina Adinda Mega Cahyani on 05/02/23.
//

import SwiftUI

struct LargeItemset1View: View {
    @Environment(\.colorScheme) var colorScheme
    @State var orientation: UIDeviceOrientation = UIDevice.current.orientation
    @State public var device = UIDevice.current.userInterfaceIdiom
    @State var dissapear:Bool = false
    @State var dictItems = [String: Int]()
    @State var dictDisappear = [String: Bool]()
    @State var largeItemSet = Set<String>()
    @State var counter:Int = 0
    @State var done:Bool = false
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(dictDisappear)
    }
    
    var body: some View {
        
        GeometryReader { geo in
            //            ZStack{
            VStack(spacing: device == .pad ? 10: 5){
                
                //                        MARK: USE TABLE
                TableTransactionView()
                
                
                    .frame(width: device == .pad ? 700: 400, height: device == .pad ? 400: 200)
                
                HStack{
                    Text("support(X) = ")
                        .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                        .aspectRatio(contentMode: .fit)
                    VStack{
                        Text("number of transactions containing X ")
                            .underline()
                            .aspectRatio(contentMode: .fit)
                            .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                        Text("total number of transactions in the dataset")
                            .baselineOffset(10)
                            .aspectRatio(contentMode: .fit)
                            .font(.system(size: device == .pad ? 30: 10, weight: .medium, design: .default))
                            .lineLimit(nil)
                    }
                    
                }
                .background(.yellow)
                
                Text("Minimum Support: 50%")
                    .multilineTextAlignment(.leading)
                    .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                
                
                Text("A frequent itemset refers to a group of items that appear together more often than a minimum support threshold specified in a transaction. Now, let's eliminate items that have a support of less than 50% or occur less than twice.")
                    .font(.system(size: device == .pad ? 28 : 14, weight: .medium, design: .default))
                
                
                VStack{
                    ForEach(transaction1,id:\.id) { trans in
                        HStack{
                            ForEach(trans.items,id:\.self){ item in
                                //                                Spacer()
                                HStack{
                                    VStack{
                                        Image(item)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: device == .pad ? 90: 30)
                                            .opacity(dictDisappear[item] ?? true ? 0 : 1)
                                        
                                    }
                                    
                                    
                                }
                                
                                
                                
                            }
                            
                            
                        }
                        
                        
                    }
                    
                    
                }
                
                
                if self.done == false{
                    Button {
                        for item in dictItems{
                            if item.value < 2{
                                dictDisappear[item.key] = true
                                
                            }
                            else{
                                largeItemSet.insert(item.key)
                            }
                        }
                        print("dictDiasappear: ",dictDisappear)
                        print("Large Itemset 1: ", largeItemSet)
                        print(dictItems)
                        self.done = true
                    }
                label: {
                    ZStack{
                        Text("Generate 1st Large Itemset")
                            .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                            .foregroundColor(colorScheme == .dark ? .white : .black)
                            .padding()
                            .fixedSize(horizontal: true, vertical: false)
                            .frame(alignment: .center)
                            .background(
                                RoundedRectangle(cornerRadius: 8)
                            )
                    }
                    
                    
                    
                }
                    
                    
                    
                }
                else{
                    NavigationLink {
                        LargeItemset2View(LargeItemset1: $largeItemSet)
                    } label: {
                        VStack{
                            HStack{
                                Text("Large Itemset 1: { ")
                                    .font(.system(size: device == .pad ? 45 : 15, weight: .light, design: .default))
                                ForEach(Array(largeItemSet),id:\.self) { item in
                                    Image(item)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: device == .pad ? 90 : 30)
                                }
                                Text(" }")
                                    .font(.system(size: device == .pad ? 45 : 15, weight: .light, design: .default))
                            }
                            
                            ZStack{
                                Text("Generate Large Itemset 2")
                                    .font(.system(size: device == .pad ? 45: 15, weight: .medium, design: .default))
                                    .foregroundColor(colorScheme == .dark ? .white : .black)
                                    .padding()
                                    .fixedSize(horizontal: true, vertical: false)
                                    .frame(alignment: .center)
                                    .background(
                                        RoundedRectangle(cornerRadius: 8)
                                    )
                                
                            }
                            
                        }
                        
                        
                        
                    }
                }
            }
            .onAppear{
                //reset the value
                done = false
                dictItems = [:]
                dictDisappear = [:]
                largeItemSet = []
                
            }
            
            
            
            
            //            }
        }
        //        show transaction
        .onAppear{
            for trans in transaction1{
                for item in trans.items{
                    dictDisappear[item] = false
                    dictItems[item] = (dictItems[item] ?? 0) + 1
                    print("item:  ",item,"dictDisappear: ",dictDisappear[item]!)
                    print("dictDisappear: ", dictDisappear)
                    
                }
                
                
            }
            
        }
        
    }
    
}

struct LargeItemset1View_Previews: PreviewProvider {
    static var previews: some View {
        LargeItemset1View()
    }
}
